local skynet = require "skynet"
require "skynet.manager"	-- import skynet.abort

skynet.abort()
